/*######################################################################
#
# Project: DoD Configuration Extension
# URL: https://software.forge.mil/sf/projects/community_cac
# E-mail: neil.mcnab@navy.mil
# E-mail: neil.mcnab@us.army.mil
# E-mail: neil.mcnab@ugov.gov
#
# Copyright: (C) 2003-2008, Neil McNab
# License: GNU General Public License Version 2
#   (http://www.gnu.org/copyleft/gpl.html)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
#
# Filename: $URL: https://svn.forge.mil/svn/repos/mozilla-dodconfig/trunk/dod_configuration/content/main.js $
# Author(s): Neil McNab
# Last Updated: $Date: 2011-01-11 11:47:02 -0500 (Tue, 11 Jan 2011) $
#
######################################################################*/

dod_update_security_level();
load_certs();
update_path();

//delay of popups until after the browser is loaded, kind of a hack
window.setTimeout('start()', 5000);

// see xulplanet.com for mozilla API

var prefManager = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefBranch);

//always load this stuff

if (isBrowser()){
  //make .mil addresses green address bar
  //try https when http fails

  //var urlbar = document.getElementById("urlbar");
  //urlbar.setAttribute('style','font-weight: bold;');
  //urlbar.addEventListener("load", urlbar.setAttribute('style','font-weight: bold;'), true);
  //urlbar.oninput = urlbar.oninput + " alert('this is my message.');";
  //onchange, urlbar.value

  var dodListener = createListener();
  window.addEventListener("load", function() { dodListener.init(); }, false);

  //this was added after version 0.6.1
  if (prefManager.getIntPref("extensions.dod.version") <= 61) {
    prefManager.setCharPref("security.default_personal_cert", "Ask Every Time");
  }
}

if (isMail()) {
}

function start() {

//only do this stuff once (on first run)!
if (prefManager.getIntPref("extensions.dod.version") == 0) {

  // Activate OCSP checking
  //prefManager.setIntPref("security.OCSP.enabled","1");
  // Turn on all auto updates
  prefManager.setBoolPref("app.update.auto",true);
  prefManager.setBoolPref("app.update.enabled",true);
  prefManager.setBoolPref("extensions.update.enabled",true);

  if (isBrowser()) {
    //update search engines automatically
    prefManager.setBoolPref("browser.search.update",true);
    prefManager.setCharPref("security.default_personal_cert", "Ask Every Time");
  }

  if (isMail()) {
    //Setup DoD LDAP
    var nospaces = install_ldap();
    // set (default) autocomplete server here
    prefManager.setCharPref("ldap_2.autoComplete.directoryServer", "ldap_2.servers." + nospaces);
  }

  var answer = confirm("Do you want to setup your smart card reader for use?");

  if (answer) {
    install_cac();
  }

}

  //do this stuff on first run AND upgrade
  if (prefManager.getIntPref("extensions.dod.version") != DOD_CURRENT_VER) {

    install_certs();

    prefManager.setIntPref("extensions.dod.version", DOD_CURRENT_VER);
  }
}


function createListener() {
var dodListener =
{
  init: function() {
    gBrowser.addProgressListener(this,
       Components.interfaces.nsIWebProgress.NOTIFY_STATE_DOCUMENT);

  },
  QueryInterface: function(aIID)
  {
   if (aIID.equals(Components.interfaces.nsIWebProgressListener) ||
       aIID.equals(Components.interfaces.nsISupportsWeakReference) ||
       aIID.equals(Components.interfaces.nsISupports))
     return this;
    throw Components.results.NS_NOINTERFACE;
  },

  onStateChange: function(aProgress, aRequest, aFlag, aStatus) {
    if (aFlag & Components.interfaces.nsIWebProgressListener.STATE_STOP){
      //check for http URL here
      //SSL cert, adds clearer error message than -12227
      if (aStatus == 2147500037 && prefManager.getBoolPref("extensions.dod.enable_cac_alert")) {
		var uri = aRequest.name;
		//alert("flag: " + aRequest.loadFlags);
		if (confirm("This website may require a SSL client certificate.\n\nPlease insert your smartcard or Common Access Card (CAC) and choose OK to try again.")) {
	          	//reload page here
			//aProgress.loadURI(aRequest.name, 0, null, null, null);
			aProgress.DOMWindow.location.href = uri;
        	}
      }
      // do https redirect here
      if (aStatus == 2152398862 && prefManager.getBoolPref("extensions.dod.enable_https_redirect")) {
	var uri = aRequest.name;
        //alert(aProgress.DOMWindow.location.href);

	if (uri.substring(0,5) == "http:") {
		uri = "https:" + uri.substring(5);
		//LOAD_FLAGS_NONE
		//aProgress.loadURI(uri, 0, null, null, null);
		//Progress.setCurrentURI(uri);
		aProgress.DOMWindow.location.href = uri;
		//aProgress.reload();
        }
      }
    }
    return 0;
  },

  onLocationChange: function(aProgress, aRequest, aURI)
  {
    // This fires when the location bar changes i.e load event is confirmed
    // or when the user switches tabs
    // sets the text type in the url bar
    if(!prefManager.getBoolPref("extensions.dod.enable_domain_highlight")) {
        return -1;
    }
    
	var urlbar = document.getElementById("urlbar");
	try {
		var host = String(aURI.host);
		host = host.toLowerCase();

	    	if(trusted_domain(host)) {
        		urlbar.setAttribute("style","font-weight: bold;");
        		urlbar.inputField.setAttribute("style","color: #008800;"); //green
			return 0;
		}
	} catch (e) {}

	urlbar.setAttribute("style","font-weight: normal;");
	urlbar.inputField.setAttribute("style","color: #000000;"); //black

    return 0;
  },

  // For definitions of the remaining functions see XulPlanet.com
  onProgressChange: function() {return 0;},
  onStatusChange: function() {return 0;},
  onSecurityChange: function(progress, context, state) {
    return 0;
  },
  onLinkIconAvailable: function() {return 0;}
}
return dodListener;
}
