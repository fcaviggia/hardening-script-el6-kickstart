/*######################################################################
#
# Project: DoD Configuration Extension
# URL: https://software.forge.mil/sf/projects/community_cac
# E-mail: neil.mcnab@navy.mil
# E-mail: neil.mcnab@us.army.mil
# E-mail: neil.mcnab@ugov.gov
#
# Copyright: (C) 2003-2007, Neil McNab
# License: GNU General Public License Version 2
#   (http://www.gnu.org/copyleft/gpl.html)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
#
# Filename: $URL: https://svn.forge.mil/svn/repos/mozilla-dodconfig/trunk/dod_configuration/content/viewpane.js $
# Author(s): Neil McNab
# Last Updated: $Date: 2010-06-11 19:00:33 -0400 (Fri, 11 Jun 2010) $
#
######################################################################*/

// Whenever the messagepane loads, update info
const IPRegEx = /^.*\[([\d\.]+)\].*/;

var messagepane = document.getElementById("messagepane");
messagepane.addEventListener("load", getclassificationheader, true);
messagepane.addEventListener("load", getdomainwarning, true);

// intercept reply to all callback
addEventListener("load", function () {
    var oldsm = MsgReplyToAllMessage;
    MsgReplyToAllMessage = function (event) {
        if (prefManager.getBoolPref("extensions.dod.replyall_warning")) {
            if (confirm("WARNING: You are about to reply to ALL!  Using this option with mailing lists can send the message to EVERYONE on the list.  Are you sure you want to do this?!")) {
                oldsm(event);
            } else {
                MsgReplyMessage(event);
            }
        } else {
            oldsm(event);
        }
        }
    }, false);

function dodupdatestatus(in_domain) {
	// update the message pane with what we know

  if (is_gteq(THUNDERBIRD_ID, "3.0")) {
    // For Thunderbird 3.0 and newer versions
    var label = document.getElementById("expandeddomainwarningrowLabel");
    var value = document.getElementById("expandeddomainwarningrowBox");
    if (in_domain == 0) {
        label.hidden = true;
        value.hidden = true;
    }
	if (in_domain > 0) {
		value.headerValue = "THIS MESSAGE DOES NOT ORIGINATE FROM THE " + prefManager.getCharPref("extensions.dod.domain").toUpperCase() + " DOMAIN!  It could be forged if no digital signature is present.";
		label.setAttribute("style", "color: #FF0000");
        label.hidden = false;
        value.hidden = false;

	} else if (in_domain < 0) {
		value.headerValue = "Could not verify that this message originated from within the " + prefManager.getCharPref("extensions.dod.domain") + " network.  You might be working offline.";
		label.setAttribute("style", "color: #FFFF00");
        label.hidden = false;
        value.hidden = false;
	}    
  } else {
    // old way to do it
	var expandeddomainwarningBox = document.getElementById("expandeddomainwarningBox");

    if (in_domain == 0) {
        expandeddomainwarningBox.hidden = true;
    } else if (in_domain > 0) {
		expandeddomainwarningBox.headerValue = "THIS MESSAGE DOES NOT ORIGINATE FROM THE " + prefManager.getCharPref("extensions.dod.domain").toUpperCase() + " DOMAIN!  It could be forged if no digital signature is present.";
		expandeddomainwarningBox.setAttribute("style", "color: #FF0000");
		expandeddomainwarningBox.hidden = false;

	} else if (in_domain < 0) {
		expandeddomainwarningBox.headerValue = "Could not verify that this message originated from within the " + prefManager.getCharPref("extensions.dod.domain") + " network.  You might be working offline.";
		expandeddomainwarningBox.setAttribute("style", "color: #FFFF00");
		expandeddomainwarningBox.hidden = false;
	} 
  }
    
};

function is_gteq(id, ver) {
    // check if app version is greater than or equal to
    if(appInfo.ID == id) {
        // running under id
        var versionChecker = Components.classes["@mozilla.org/xpcom/version-comparator;1"].getService(Components.interfaces.nsIVersionComparator);
        if(versionChecker.compare(appInfo.version, ver) >= 0) {
            return true;
        }
    }
    return false;
}

function getdomainwarning() {
	// reset to not display anything (message is OK)
	dodupdatestatus(0);
	// kick out of function, we aren't checking the message
    	if (!prefManager.getBoolPref("extensions.dod.forged_warning")) {
        	return;
    	}
        try {
            var uri = GetFirstSelectedMessage();
        } catch (e) {
	    try {
                var uri = gFolderDisplay.selectedMessageUris[0];
	    } catch (e) { return; };
        }

    try {
 	var msgService = messenger.messageServiceFromURI(uri);
    } catch (e) {};

    var dataListener = {
		stream : null,
		h : "",
		host: "",
		in_domain: 0,
        
		writeFrom: function(fromStream, count) {
			this.onDataAvailable(null, null, fromStream, 0, count);
		},
		handledns: function(data) {

			data = String(data);

			// no need to check the same server twice in a row
			if (this.host == data) {
				return;
			}

			this.host = data;

			// ignore localhost, that doesn't help us determine origin
			if (this.host == "localhost") {
				return;
			}

			// unable to determine, no hostname for reverse lookup
			if ((this.host == "") || ("null" == this.host)) {
				this.in_domain = -1;
				dodupdatestatus(this.in_domain);
				return;
			}
			
			// finally, check is a host is in our domain, if not, flag warning
			if (!trusted_domain(this.host)) {
				this.in_domain = 2;
				dodupdatestatus(this.in_domain);
				return;
			}

			
		},

		onStartRequest: function(request, context) {},
		onStopRequest: function(request, context, status) { },
		onDataAvailable: function(request, context, inputStream, offset, count) {

			this.in_domain = 0;
			dodupdatestatus(this.in_domain);

			var lines = read_stream(inputStream, count);
			var myheader = "Received: ";

			for (i = 0; i < lines.length; i++) {
				// check for matching header
				if (lines[i].substr(0, myheader.length) == myheader) {
					var parts = IPRegEx.exec(lines[i]);
					try {
						var ip = parts[1];
					} catch (e) {}

					// if offline, this will still error out, need to fix
					try {
						queryDNS(DNS_ReverseIPHostname(ip), "PTR", this.handledns);	
					} catch (e) {
						if (this.in_domain <= 0) {
							this.in_domain = -1;
							dodupdatestatus(this.in_domain);
						}
					}
				
				}
			}
		
		}
    };

	var async_consumer = Components.classes["@mozilla.org/network/simple-stream-listener;1"].createInstance();
	var async_consumer2 = async_consumer.QueryInterface(Components.interfaces.nsISimpleStreamListener);

	async_consumer2.init(dataListener, null);

	try {
		msgService.streamMessage(uri, async_consumer, msgWindow, null, false, null)
	} catch (ex) {
		return;
	}
	
}

function classification_update(level) {
    if (level == "") {
        if (is_gteq(THUNDERBIRD_ID, "3.0")) {
            document.getElementById("expandedclassificationrowLabel").hidden = true;
            document.getElementById("expandedclassificationrowBox").hidden = true;
        } else {
            document.getElementById("expandedclassificationBox").hidden = true;
        }
        return;
    }

    if (is_gteq(THUNDERBIRD_ID, "3.0")) {
        var label = document.getElementById("expandedclassificationrowLabel");
        var value = document.getElementById("expandedclassificationrowBox");
        value.headerValue = level;
        label.hidden = false;
        value.hidden = false;
    } else {
        var expandedclassificationBox = document.getElementById("expandedclassificationBox");
        expandedclassificationBox.headerValue = level;
        expandedclassificationBox.hidden = false;
    }
}

function getclassificationheader() {
    classification_update("");
    try {
        var uri = GetFirstSelectedMessage();
    } catch (e) {
        try {
            var uri = gFolderDisplay.selectedMessageUris[0];
	} catch (e) { return; };
    }

    try {
    	var msgService = messenger.messageServiceFromURI(uri);
    } catch (e) {};
	
    var dataListener = {
		stream : null,
		h : "",
		mode : 0, // 0=Looking for first Received:, 1=Looking for second Received:
		hcont : false,
		hlast : "",
		bytesread : 0,
        
		writeFrom: function(fromStream, count) {
			this.onDataAvailable(null, null, fromStream, 0, count);
		},
		onStartRequest: function(request, context) {},
		onStopRequest: function(request, context, status) { },
		onDataAvailable: function(request, context, inputStream, offset, count) {

			var lines = read_stream(inputStream, count);

			// handle header
			var myheader = "X-Security-Classification: ";
            var xsmtpheader = "X-P772-Security-Classification: ";

			for (i = 0; i < lines.length; i++) {
				// check if header matches
    			if (lines[i].substr(0, myheader.length) == myheader) {
                    var temp = lines[i].substr(myheader.length).split(";");
                    classification_update(temp[0]);
				}
                if (lines[i].substr(0, xsmtpheader.length) == xsmtpheader) {
                    var temp = lines[i].substr(xsmtpheader.length);
                    classification_update(temp);
                }
			}
		}
    };

	var async_consumer = Components.classes["@mozilla.org/network/simple-stream-listener;1"].createInstance();
	var async_consumer2 = async_consumer.QueryInterface(Components.interfaces.nsISimpleStreamListener);

	async_consumer2.init(dataListener, null);

	try {
		msgService.streamMessage(uri, async_consumer, msgWindow, null, false, null)
	} catch (ex) {
		return;
	}
	
}
