var prefManager = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefBranch);

function stig_apply() {
    var ret = confirm("Do you really want to apply the DISA STIG settings?  This may break things.");
    if (ret) {
        stig_settings();
        stig_audit();
    }
}

function stig_settings() {
    if (!root_cert_exists()) {
        install_certs();
    }
    prefManager.setBoolPref("security.enable_ssl3", false);
    prefManager.setCharPref("security.default_personal_cert", "Ask Every Time");
    prefManager.setBoolPref("network.protocol-handler.external.shell", false);
    // this takes mime types or extensions?
    //prefManager.setCharPref("plugin.disable_full_page_plugin_for_types", "PDF, FDF, XFDF, LSL, LSO, LSS, IQY, RQY, XLK, XLS, XLT, POT, PPS, PPT, DOS, DOT, WKS, BAT, PS, EPS, WCH, WCM, WB1, WB3, RTF");
    // TODO FireFox plug-in for ActiveX controls is installed.
    prefManager.setBoolPref("browser.formfill.enable", false);
    prefManager.setBoolPref("signon.prefillForms", false);
    prefManager.setBoolPref("signon.autofillForms", false);
    prefManager.setBoolPref("signon.rememberSignons", false);
    prefManager.setBoolPref("privacy.sanitize.promptOnSanitize", false);
    prefManager.setBoolPref("privacy.sanitize.sanitizeOnShutdown", true);
    prefManager.setBoolPref("dom.disable_window_open_feature.status", true);
    prefManager.setBoolPref("dom.disable_window_move_resize", true);
    prefManager.setBoolPref("security.enable_ssl2", false);
    prefManager.setBoolPref("security.enable_tls", true);
    prefManager.setBoolPref("dom.disable_window_flip", true);
    prefManager.setBoolPref("dom.event.contextmenu.enabled", false);
    prefManager.setBoolPref("dom.disable_window_status_change", true);
    prefManager.setBoolPref("dom.disable_window_open_feature.status", true);
    prefManager.setBoolPref("security.warn_leaving_secure", true);
}

function stig_audit() {
    var audit_list = [];
    // check root sha1 sum here, 10 f1 93 f3 40 ac 91 d6 de 5f 1e dc 00 62 47 c4 f2 5d 96 71
    if (!root_cert_exists()) {
        audit_list.push("DoD Root Certificate is not installed.");
    }
    if (prefManager.getBoolPref("security.enable_ssl3")) {
        audit_list.push("Firefox is configured to allow use of SSL 3.0.");
    }
    if (!prefManager.getCharPref("security.default_personal_cert", "Ask Every Time")) {
        audit_list.push("FireFox is not configured to ask which certificate to present to a web site when a certificate is required.");
    }
    // TODO Rule Title: Firefox automatically executes or downloads MIME types which are not authorized for auto-download.
    if (prefManager.getBoolPref("network.protocol-handler.external.shell")) {
        audit_list.push("Network shell protocol is enabled in FireFox.");
    }
    // Firefox not configured to prompt user before download and opening for required file types.
    // TODO this only checks plugins
    var exts = ["hta", "jse", "js", "mocha", "shs", "vbe", "vbs", "sct", "wsc"];
    for (var i = 0; i < exts.length; i++) {
        var ext = exts[i];
        var app = extension_enabled(ext);
        if (app != "") {
            audit_list.push("Firefox not configured to prompt user before download and opening for ." + ext + ".");
        }
    }
    if (activex_enabled()) {
        audit_list.push("FireFox plug-in for ActiveX controls is installed.");
    }
    if (prefManager.getBoolPref("browser.formfill.enable")) {
        audit_list.push("Firefox formfill assistance option is disabled.");
    }

    var val = true;
    try {
       var val = prefManager.getBoolPref("signon.prefillForms");
    } catch (e) {};
    val = val || prefManager.getBoolPref("signon.autofillForms");
    if (val) {
        audit_list.push("Firefox is configured to autofill passwords.");
    }

    if (prefManager.getBoolPref("signon.rememberSignons")) {
        audit_list.push("FireFox is configured to use a password store with or without a master password.");
    }

    var val = true;
    try {
       var val = prefManager.getBoolPref("privacy.sanitize.promptOnSanitize");
    } catch (e) {};
    val = val || !prefManager.getBoolPref("privacy.sanitize.sanitizeOnShutdown");
    if (val) {
        audit_list.push("Firefox does not clear cookies upon closing.");
    }

    if (!prefManager.getBoolPref("dom.disable_window_open_feature.status")) {
        audit_list.push("FireFox is not configured to block pop-up windows.");
    }
    if (!prefManager.getBoolPref("dom.disable_window_move_resize")) {
        audit_list.push("FireFox is configured to allow JavaScript to move or resize windows.");
    }
    if (prefManager.getBoolPref("security.enable_ssl2")) {
        audit_list.push("The Firefox SSLV2 parameter is configured to allow use of SSL 2.0.");
    }
    if (!prefManager.getBoolPref("security.enable_tls")) {
        audit_list.push("Firefox is not configured to allow use of TLS 1.0.");
    }
    if (!prefManager.getBoolPref("dom.disable_window_flip")) {
        audit_list.push("Firefox is configured to allow JavaScript to raise or lower windows.");
    }
    if (prefManager.getBoolPref("dom.event.contextmenu.enabled")) {
        audit_list.push("Firefox is configured to allow JavaScript to disable or replace context menus.");
    }
    if (!prefManager.getBoolPref("dom.disable_window_status_change")) {
        audit_list.push("Firefox is configured to allow JavaScript to hide or change the status bar.");
    }
    if (!prefManager.getBoolPref("dom.disable_window_open_feature.status")) {
        audit_list.push("Firefox is configured to allow JavaScript to change the status bar text.");
    }
    if (!prefManager.getBoolPref("security.warn_leaving_secure")) {
        audit_list.push("Firefox is not configured to provide warnings when a user switches from a secure (SSL-enabled) to a non-secure page.");
    }
    if (!stig_is_gteq("3")) {
        audit_list.push("Installed version of Firefox unsupported (less than 3).");
    }
    var audit_string = "The following findings exist:\r\n\r\n" + audit_list.join("\r\n\r\n");
    if (audit_list.length > 0) {
        alert(audit_string);
    } else {
        alert("Everything looks good!");
    }
}

////// Test support functions


function stig_is_gteq(ver) {
    // check if app version is greater than or equal to
    const id = "{ec8030f7-c20a-464f-9b0e-13a3a9e97384}";
    if(appInfo.ID == id) {
        // running under id
        var versionChecker = Components.classes["@mozilla.org/xpcom/version-comparator;1"].getService(Components.interfaces.nsIVersionComparator);
        if(versionChecker.compare(appInfo.version, ver) >= 0) {
            return true;
        }
    }
    return false;
}

function root_cert_exists() {
	return check_fingerprint("DoD CLASS 3 Root CA - U.S. Government", "10:F1:93:F3:40:AC:91:D6:DE:5F:1E:DC:00:62:47:C4:F2:5D:96:71");
}

function check_fingerprint(name, sha1) {
        var certdb1 = Components.classes["@mozilla.org/security/x509certdb;1"].getService(Components.interfaces.nsIX509CertDB);
        try {
            var cert = certdb1.findCertByNickname(null, name);
        } catch (e) {
            //alert("root cert not found");
            return false;
        };
        if (cert == null) {
            //alert("root cert not found 2");
            return false;
        }
        if (cert.sha1Fingerprint == sha1) {
            return true;
        }
	return false;    
}

function extension_enabled(ext) {
    for (var i = 0; i < navigator.mimeTypes.length; i++) {
        var suffixes = navigator.mimeTypes[i].suffixes.split(",");
        for (var j = 0; j < suffixes.length; j++) {
            suffix = suffixes[j];
            if (suffix.toLowerCase() == ext.toLowerCase()) {
                return navigator.mimeTypes[i].description;
            }
        }
    }
    return "";
}


function activex_enabled() {
    return plugin_enabled("application/oleobject");
}

function plugin_enabled(mimetype) {
    nse = ""; for (var i=0;i<navigator.mimeTypes.length;i++) nse += navigator.mimeTypes[i].type.toLowerCase();
    if (nse.indexOf(mimetype) == -1) {
        return false;
    }
    if (navigator.mimeTypes[mimetype] != null) {
        return true;
    }
    return false;
}