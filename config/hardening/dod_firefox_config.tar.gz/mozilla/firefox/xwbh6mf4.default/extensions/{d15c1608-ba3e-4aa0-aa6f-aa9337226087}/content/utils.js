/*######################################################################
#
# Project: DoD Configuration Extension
# URL: https://software.forge.mil/sf/projects/community_cac
# E-mail: neil.mcnab@navy.mil
# E-mail: neil.mcnab@us.army.mil
# E-mail: neil.mcnab@ugov.gov
#
# Copyright: (C) 2003-2011, Neil McNab
# License: GNU General Public License Version 2
#   (http://www.gnu.org/copyleft/gpl.html)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
#
# Filename: $URL: https://svn.forge.mil/svn/repos/mozilla-dodconfig/trunk/dod_configuration/content/utils.js $
# Author(s): Neil McNab
# Last Updated: $Date: 2011-08-19 12:10:36 -0400 (Fri, 19 Aug 2011) $
#
######################################################################*/

//global utilities go in here

const DOD_CURRENT_VER=134;
const DOD_TITLE="DoD Configuration Extension";
const EXT_ID = "{d15c1608-ba3e-4aa0-aa6f-aa9337226087}";

const FIREFOX_ID = "{ec8030f7-c20a-464f-9b0e-13a3a9e97384}";
const THUNDERBIRD_ID = "{3550f703-e582-4d05-9a08-453d09bdfdc6}";
var appInfo = Components.classes["@mozilla.org/xre/app-info;1"].getService(Components.interfaces.nsIXULAppInfo);
var certdb1 = Components.classes["@mozilla.org/security/x509certdb;1"].getService(Components.interfaces.nsIX509CertDB);
var certdb = Components.classes["@mozilla.org/security/x509certdb;1"].getService(Components.interfaces.nsIX509CertDB2);

var prefManager = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefBranch);

///////////////////// Generic functions

function isBrowser() {
	if (prefManager.getPrefType("browser.chromeURL") != 0) {
		return true;
	}
    var info = Components.classes["@mozilla.org/xre/app-info;1"].getService(Components.interfaces.nsIXULAppInfo);
// Get the name of the application running us
    if (info.name == "Firefox") {
        return true;
    }
	return false;
}

function isMail() {
	if (prefManager.getPrefType("mail.remember_password") != 0) {
		return true;
	}
    var info = Components.classes["@mozilla.org/xre/app-info;1"].getService(Components.interfaces.nsIXULAppInfo);
// Get the name of the application running us
    if (info.name == "Thunderbird") {
        return true;
    }
	return false;
}

function is_gteq(id, ver) {
    // check if app version is greater than or equal to
    if(appInfo.ID == id) {
        // running under id
        var versionChecker = Components.classes["@mozilla.org/xpcom/version-comparator;1"].getService(Components.interfaces.nsIVersionComparator);
        if(versionChecker.compare(appInfo.version, ver) >= 0) {
            return true;
        }
    }
    return false;
}

function my_path() {
    var directoryService = Components.classes["@mozilla.org/file/directory_service;1"].getService(Components.interfaces.nsIProperties);
    var ext = directoryService.get("ProfD", Components.interfaces.nsIFile);
    ext.append("extensions");
    ext.append(EXT_ID);
    return ext;
}

function trusted_domain(check_string) {
	domainpref = prefManager.getCharPref("extensions.dod.domain");
	domains = domainpref.toLowerCase().split(",");
	check_string = check_string.toLowerCase();

        for(i = 0; i < domains.length; i++) {
        	domain = domains[i].replace(/ /,"");
		if (domain[0] != ".") {
			domain = "." + domain;
		}
            var check = check_string.lastIndexOf(domain);
		if ((check != -1) && (check == (check_string.length - domain.length))) {
			return true;
		}
        }
	return false;
}

function get_array(branch_base) {
	var prefs = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);
	var branch = prefs.getBranch(branch_base);
	var children = branch.getChildList("", {});
	var children_list = String(children).split(",");
	children_list = children_list.sort();

	return children_list;
}

function readFile(filename) {
	var file = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsILocalFile);
	file.initWithPath(filename);
	if ( file.exists() == false ) {
		alert("File does not exist " + file.path);
	}
	var is = Components.classes["@mozilla.org/network/file-input-stream;1"].createInstance( Components.interfaces.nsIFileInputStream );
	is.init(file,0x01, 00004, null);
	var sis = Components.classes["@mozilla.org/binaryinputstream;1"].createInstance( Components.interfaces.nsIBinaryInputStream );
    sis.setInputStream(is);
    var output = sis.readBytes( sis.available());

	is.close();
	sis.close();

	return output;
}

function endswith(mainstring, endstring) {
	if (mainstring.lastIndexOf(endstring) == (mainstring.length - endstring.length)) {
		return true;
	}
	return false;	
}

function is_readable(filename) {

	var myfile = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsILocalFile);
	var result = false;
	try {
		myfile.initWithPath(filename);
		var result = myfile.isReadable();
	} catch (e) {result = false};
	return result;
}

function exists(filename) {

	var myfile = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsILocalFile);
	var result = false;
	try {
		myfile.initWithPath(filename);
		var result = myfile.exists();
	} catch (e) {result = false};
	return result;
}

function log_message(aMessage) {
  var consoleService = Components.classes["@mozilla.org/consoleservice;1"].getService(Components.interfaces.nsIConsoleService);
  consoleService.logStringMessage("DoD Configuration: " + aMessage);
}

//////////////////

//////////////// Check mail headers feature

function read_stream(inputStream, count){
	var stream = Components.classes["@mozilla.org/binaryinputstream;1"].createInstance(Components.interfaces.nsIBinaryInputStream);
	stream.setInputStream(inputStream);

	var c;
	var csi;
	var h = "";
			
	// PARSE THE HEADERS
	for (csi = 0; csi < count; csi++) {
		c = String.fromCharCode(stream.read8());
		h += c;
	}

	// handle continuation lines
	h = h.replace(/(\r\n\s)/g, "");

	// return array of lines
	return h.split("\r\n");
}

function DNS_ReverseIPHostname(ip) {
	var q = ip.split(".");
	return q[3] + "." + q[2] + "." + q[1] + "." + q[0] + ".in-addr.arpa";
}

/////////////////////////
////////////////////// security levels feature

function dod_update_security_level() {
	var security_level = prefManager.getIntPref("extensions.dod.security_level");

	if (security_level <= 50) {
		//lowest security level, minimum settings apply
	    	//turn off javascript
    		prefManager.setBoolPref("javascript.allow.mailnews", false);

	    	//disable remote image loading
    		prefManager.setBoolPref("mailnews.message_display.disable_remote_image", true);

	}
	if (security_level <= 40) {
		// disable HTML email composing
		var ids = get_array("mail.identity.id");
		var prev = "";
		for (i = 0; i < ids.length; i++) {
			var id = ids[i];
			var parts = id.split("\.");
			id = parts[0];
			if (id != prev) {
				prefManager.setBoolPref("mail.identity.id" + id + ".compose_html", "false");
			}
			prev = id;
		}
		prefManager.setBoolPref("mail.html_compose", "false");
		prefManager.setBoolPref("mail.identity.default.compose_html", "false");

		//disable HTML viewing, set to plain text
		prefManager.setIntPref("mailnews.display.html_as", "1");
		
	}
	if (security_level <= 30) {
		// disable preview pane
		//loop through all open windows
		var wm = Components.classes["@mozilla.org/appshell/window-mediator;1"]
                   .getService(Components.interfaces.nsIWindowMediator);
		var enumerator = wm.getEnumerator(null);
		while(enumerator.hasMoreElements()) {
			var win = enumerator.getNext();
			var splitter = win.document.getElementById("threadpane-splitter");
			try {
				splitter.setAttribute("state", "collapsed");
			} catch (e) {}
		}  
	}
	if (security_level <= 20) {
	
	}
	if (security_level <= 10) {
		//highest security level
	}

}
/////////////////////
//////////////////// CAC setup feature

function install_cac() {
  //add CAC reader module
  var cac_status = false;

  const cac_reader_name = "CAC Reader (DoD Configuration Extension)";
  var pf = Components.classes["@mozilla.org/process/environment;1"].getService(Components.interfaces.nsIEnvironment).get('PROGRAMFILES');
  var windir = Components.classes["@mozilla.org/process/environment;1"].getService(Components.interfaces.nsIEnvironment).get('WINDIR');
  var pkcs11 = Components.classes["@mozilla.org/security/pkcs11;1"].getService(Components.interfaces.nsIPKCS11);

  const driver_list = [
                       // Windows
                       windir + "\\system32\\acpkcs201-ns.dll",						// Activcard
                       windir + "\\system32\\acpkcs.dll",         
                       windir + "\\system32\\acpkcs211.dll",
                       windir + "\\system32\\acpkcs201.dll",
                       windir + "\\system32\\acpkcs201-en6.dll",
                       pf + "\\ActivIdentity\\ActivClient\\acpkcs201-en6.dll",
                       pf + "\\ActivIdentity\\ActivClient\\acpkcs201.dll",
                       windir + "\\system32\\libcoolkeypk11.dll", windir + "\\system32\\coolkeypk11.dll",	// Coolkey
                       windir + "\\system32\\libcackey.dll",						// CACKey
                       // Linux
                       "/usr/local/acgold/lib/libpkcs11.so",        					// ActivCard
                       "/usr/lib/libmusclepkcs11.so", "/usr/local/lib/libmusclepkcs11.so", 		// Muscle Card
                       "/usr/lib/libcoolkeypk11.so", "/usr/local/lib/pkcs11/libcoolkeypk11.so",		// Coolkey
                       "/usr/lib/pkcs11/libcoolkeypk11.so", "/usr/lib64/pkcs11/libcoolkeypk11.so", 
                       "/usr/local/lib/libcackey.so", "/usr/lib64/libcackey.so", "/usr/lib/libcackey.so",	// CACKey
                       // Mac OS X native
                       "/usr/libexec/SmartCardServices/pkcs11/pkcs11.bundle/Contents/MacOS/pkcs11",
                       "/usr/local/lib/pkcs11/libcoolkeypk11.dylib",
                       // 10.6 Snow Leopard native
                       "/usr/libexec/SmartCardServices/pkcs11/tokendPKCS11.so"
                       ];


  for(i = 0; i < driver_list.length; i++) {
    if (is_readable(driver_list[i])) {
      log_message("Attempting to load CAC driver: " + driver_list[i]);
      try {
          var status = pkcs11.addModule(cac_reader_name, driver_list[i], 0,0);
      } catch (e) {log_message("ERROR: Could not load: " + cac_reader_name + " " + driver_list[i] + " " + e.message);};

      // known status codes, 3 successful install, -10 already exists, -5 unable to add (file doesn't exist)
      //alert(status);
      if (status == -10 || status == 3) {
        cac_status = true;
        log_message("Loading smart card driver successful: " + driver_list[i]);
        i = driver_list.length;
      }
    }
  }


  if (cac_status) {
      alert("Smart card reader ready for use.");
  } else {
      alert("ERROR: Could not load smart card reader.");
  }

  select_email_certs();

  return cac_status;
}

function select_email_certs() {
  //if thunderbird/seamonkey, turn on sign by default, setup CAC certs
  var i = 0;
  if (isMail()) {
    var allmsg = "";
    for (i = 0; i < 10; i++) {
      if (prefManager.getPrefType("mail.identity.id" + i + ".useremail") != 0) {
        var certmsg = '';

        var email = prefManager.getCharPref("mail.identity.id" + i + ".useremail");
        log_message('Setting up certificates for ' + email);

        if (email != '') {
          var encnick = get_encryption_cert_nickname(email);
          if (encnick != null) {
            msg = "Encryption Certificate: " + encnick;
            certmsg += msg + '\n';
            log_message(msg);
            prefManager.setCharPref("mail.identity.id" + i + ".encryption_cert_name", encnick);
          }

          var nick = get_signing_cert_nickname(email);
          if (nick != null) {
            msg = "Signing Certificate: " + nick;
            certmsg += msg + '\n';
            log_message(msg);
            prefManager.setCharPref("mail.identity.id" + i + ".signing_cert_name", nick);
            prefManager.setBoolPref("mail.identity.id" + i + ".sign_mail", true);
          }

          if (certmsg != "") {
            allmsg += "Setup certificate(s) for " + email + ".\n\n";
            allmsg += certmsg + "\n\n";
          }
        }
      }
    }
    if (allmsg != "") {
        alert(allmsg);
    }
    //not sure what this actually sets
    //prefManager.setBoolPref("mail.crypto_sign_outgoing_mail", true);
  }
}

function get_encryption_cert_nickname(email) {
        var count = new Object();
        var certs = new Object();
        var i = 0;

        certdb1.findCertNicknames(null, 2, count, certs);
        for (i = 0; i < count.value; i++) {
            var cert = certs.value[i];
            var nickname = cert.slice(1, cert.lastIndexOf(cert.charAt(0)));
	    nickname = nickname.replace(cert.charAt(0),':');
            log_message("Found cert on token: " + nickname);
            var enccert = certdb1.findEmailEncryptionCert(nickname);
            if (enccert != null) {
                //log_message(enccert.emailAddress + ' ' + email);
                if (enccert.emailAddress == email) {
                    //log_message("Encrypt cert = " + enccert.nickname + " " + enccert.emailAddress);
                    return enccert.nickname;
                }
            }
        }
	return null;
}

function get_signing_cert_nickname(email) {
        var count = new Object();
        var certs = new Object();
        var i = 0;

        certdb1.findCertNicknames(null, 2, count, certs);
        for (i = 0; i < count.value; i++) {
            var cert = certs.value[i];
            var nickname = cert.slice(1, cert.lastIndexOf(cert.charAt(0)));
	    nickname = nickname.replace(cert.charAt(0),':');
            log_message("Found cert on token: " + nickname);
            var enccert = certdb1.findEmailSigningCert(nickname);
            if (enccert != null) {
                //log_message(enccert.emailAddress + ' ' + email);
                if (enccert.emailAddress == email) {
                    //log_message("Encrypt cert = " + enccert.nickname + " " + enccert.emailAddress);
                    return enccert.nickname;
                }
            }
        }
	return null;
}

function update_path() {
    // See if activclient exists in c:\program files
    var pf = Components.classes["@mozilla.org/process/environment;1"].getService(Components.interfaces.nsIEnvironment).get('PROGRAMFILES');
    if (pf == "") {
        log_message("Environment variable %PROGRAMFILES% not defined.");
        return;
    }
    var ac_path = pf + "\\ActivIdentity\\ActivClient";
    var result = exists(ac_path);
    if (!result) {
        log_message("ActivClient path does not exist: " + ac_path);
        return;
    }
    // check if it exists in PATH already
    var path = Components.classes["@mozilla.org/process/environment;1"].getService(Components.interfaces.nsIEnvironment).get('PATH');
    if (path.indexOf(ac_path) == -1) {
    // if not add it
        Components.classes["@mozilla.org/process/environment;1"].getService(Components.interfaces.nsIEnvironment).set('PATH', path + ";" + ac_path);
        log_message("PATH updated to: " + Components.classes["@mozilla.org/process/environment;1"].getService(Components.interfaces.nsIEnvironment).get('PATH'));
        return;
    }
    return;
}

//////////

/////// Cert loading method from Base64 encoded on local system

function load_certs() {

  var mylist = ["c:\\certs", "/etc/pki/cac"];

  var count = 0;
  for(i = 0; i < mylist.length; i++) {
    count += load_certs_from_dir(mylist[i]);
  }
  return count;
}

function parse_cert(certfile) {
        var beginCert = "-----BEGIN CERTIFICATE-----";
        var endCert = "-----END CERTIFICATE-----";

        certfile = certfile.replace(/[\r\n]/g, "");
        begin = certfile.indexOf(beginCert);
        end = certfile.indexOf(endCert);
        cert = certfile.substring(begin + beginCert.length, end);
//alert(cert);
	return cert;
}

function load_cert_base64(filename) {
	log_message("Installing " + filename);
	var text = readFile(filename);
	var base64 = parse_cert(text);

        //var base64 = "MIICnDCCAgWgAwIBAgIBBzANBgkqhkiG9w0BAQUFADBLMQswCQYDVQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNFQ0ExFDASBgNVBAMTC0VDQSBSb290IENBMB4XDTA0MDYxNDExMTgwOVoXDTQwMDYxNDExMTgwOVowSzELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRUNBMRQwEgYDVQQDEwtFQ0EgUm9vdCBDQTCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEArkr2eXIS6oAKIpDkOlcQZdMGdncoygCEIU+ktqY3of5SVVXU7/it7kJ1EUzR4ii2vthQtbww9aAnpQxcEmXZk8eEyiGEPy+cCQMllBY+efOtKgjbQNDZ3lB919qzUJwBl2BMxslU1XsJQw9SK10lPbQm4asa8E8e5zTUknZBWnECAwEAAaOBjzCBjDAfBgNVHSMEGDAWgBT2uAQnDlYW2blj2f2hVGVBoAhILzAdBgNVHQ4EFgQU9rgEJw5WFtm5Y9n9oVRlQaAISC8wDgYDVR0PAQH/BAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wKQYDVR0gBCIwIDAOBgpghkgBZQMCAQwBMAAwDgYKYIZIAWUDAgEMAjAAMA0GCSqGSIb3DQEBBQUAA4GBACNSI829LpO5yOTQ3Z/mNfzqSua6Kgwj/HAshgWXRtkDSlmLVvx13p8rCA5OPyf5lnA1TJ1LZk44jjIeaw7cxGJVWwibs+mHtahWwXE6p4hvkCDj7gVIclIS0nsH1vKQfvzEKqHN9iIY6oIWZT/gdELu2h3vfC91S382IZdvzzl5";

        certdb.addCertFromBase64(base64, "CT,C,", "");
}

function load_certs_from_dir(path) {
        var count = 0;

	if (is_readable(path)) {
		var contents = list_contents(path, []);
        for(i = 0; i < contents.length;i++) {
			if (endswith(contents[i].path, ".cer") && is_readable(contents[i].path)) {
				try {
					load_cert_base64(contents[i].path);
					count += 1;
				} catch (e) {};
			}
		}
	}
	return count;
}


function list_contents(path, mylist) {
	// this is recursive
	var myfile = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsILocalFile);
	myfile.initWithPath(path);
	var entries = myfile.directoryEntries;

	while(entries.hasMoreElements()) {
		var next = entries.getNext();
		next.QueryInterface(Components.interfaces.nsIFile);
		if (next.isDirectory()) {
			mylist = list_contents(next.path, mylist);
		} else {
			mylist.push(next);
		}
        }
	return mylist;
}

/*

check /etc/pki/cac/nipr/cert-release for version information?

*/

////////////////////////////////////
////////// Cert method download from websites

function file_download(url, localfile, callback) {
	var request = Components.classes["@mozilla.org/xmlextras/xmlhttprequest;1"].createInstance(Components.interfaces.nsIJSXMLHttpRequest);
	request.open("GET", url, true);
	// required for proper handling of binary files
	request.overrideMimeType('text/plain; charset=x-user-defined');
	request.onreadystatechange = function (aEvt) {
		if (request.readyState == 4) {
			if(request.status == 200) {
                log_message("Download completed " + url);
				var filepath = writeFile(localfile, request.responseText);
			} else {
				alert("Could not download certificate from " + url); Components.utils.reportError("Could not download certificate from " + url);
			}
            callback(filepath);
		}
	};
	request.send(null);
	log_message("Downloading " + url);
}

function writeFile( sFilePath, sFileContent )
{
	//create proper path

	var ext = my_path();
	ext.append("content");
	ext.append("temp");
	ext.append(sFilePath);

	try {

		var file = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsILocalFile);
		file.QueryInterface(Components.interfaces.nsIFile);
		file.initWithPath(ext.path);

		// overwrite file if it already exists
		if( file.exists() == true ) file.remove( false );

		var strm = Components.classes["@mozilla.org/network/file-output-stream;1"].createInstance(Components.interfaces.nsIFileOutputStream);
		strm.QueryInterface(Components.interfaces.nsIOutputStream);
		strm.QueryInterface(Components.interfaces.nsISeekableStream);
		strm.init( file, 0x04 | 0x08, 420, 0);
		strm.write( sFileContent, sFileContent.length );
		strm.flush();
		strm.close();
	} catch(ex) { }
	return ext.path;
}

function load_certs_from_list(root, mylist) {
  //This breaks Thunderbird for some reason if not delayed
	var ext = my_path();
	ext.append("content");
	ext.append("temp");

  if( !ext.exists() || !ext.isDirectory() ) {   // if it doesn't exist, create
    ext.create(Components.interfaces.nsIFile.DIRECTORY_TYPE, 0700);
  }

  var count = 0;
  for(i = 0; i < mylist.length; i++) {
    //dl.add("http://dodpki.c3pki.chamb.disa.mil/" + mylist[i], mylist[i]);
    count += file_download(root + mylist[i], mylist[i], load_cert);
  }
  return count;
}

function install_certs() {
  //Import DoD Certs
  var count = load_certs();
  if (count > 0) {
        alert(count + " Certificates updated from local store.");
  	return count;
  }

  var mylist = ["rel3_dodroot_2048.cac", "dodeca.cac", "dodeca2.cac", "rel3_dodroot_1024_retired.cac"]; //, "dodroot-med.cac"];

  alert("Downloading and installing the latest certificates.");
  count = load_certs_from_list("http://dodpki.c3pki.chamb.disa.mil/", mylist);
  return count;
}

function install_piv_certs() {
  var count = 0;
  
  count += install_certs();

  // See: http://www.idmanagement.gov/fpkia/
  var mylist = ["CAcertsIssuedByFBCA.p7c", "CAcertsIssuedToFBCA.p7c"];
  count += load_certs_from_list("http://fpkia.gsa.gov/FBCA/", mylist);

  var mylist = ["CommonPolicyRoot.p7c", "CAcertsIssuedByCommonPolicy.p7c"];
  count += load_certs_from_list("http://fpkia.gsa.gov/CommonPolicy/", mylist);

// New FBCA Certificates
  var mylist = ["fcpca.crt", "caCertsIssuedByfcpca.p7c", "caCertsIssuedTofcpca.p7c"];
  for(i = 0; i < mylist.length; i++) {
    count += file_download("http://http.fpki.gov/fcpca/" + mylist[i], mylist[i], load_cert);
  }

  // New FBCA Certificates
  var mylist = ["caCertsIssuedByfbca.p7c"];
  for(i = 0; i < mylist.length; i++) {
    count += file_download("http://http.fpki.gov/bridge/" + mylist[i], mylist[i], load_cert);
  }

  // New FBCA Certificates
  var mylist = ["caCertsIssuedBysha1frca.p7c"];
  for(i = 0; i < mylist.length; i++) {
    count += file_download("http://http.fpki.gov/sha1frca/" + mylist[i], mylist[i], load_cert);
  }


  return count;
}


// certificate helper code

function load_cert(filepath) {
    window.openDialog("chrome://dod/content/progressdialog.xul","progress"+filepath, "modal=no,resizable=yes", {callback: load_certs_dialog, filepath: filepath});
}

function load_certs_dialog(args) {
    load_certs_from_bundle(args.filepath);
}

function load_certs_from_bundle(filepath) {
    var j = 0;
    var certs = parse_pkcs7(filepath);

    for (j = 0; j < certs.length; j++) {     
        var b64text = base64_encode(certs[j]);
	var cert = certdb1.constructX509FromBase64(b64text);
	var text = cert.commonName;

        // actually load the certificates here
        try {
            log_message("Installing " + text);
            certdb.addCertFromBase64(b64text, "CT,C,", "");
        } catch (e) {
            log_message("Install failed for " + text + ": " + e);       
        }
    }

    return certs.length;
}

function parse_pkcs7(filepath) {
    // returns bundled certificates in DER format

    log_message("Parsing as PKCS7 " + filepath);
    // read the file here
    var str = readFile(filepath);
    var der = [];
    for (var i = 0; i < str.length; ++i) {
	der[der.length] = str.charCodeAt(i);
    }
    var asn1 = ASN1.decode(der);

    var oid = false;
    var next = null;
    var i = 0;
    var j = 0;
    var pcerts = new Array();

    for(i = 0; i < asn1.sub.length; i++) {
        if (asn1.sub[i].content() == "1.2.840.113549.1.7.2") {
            oid = true;
        } else {
            next = asn1.sub[i];
        }
    }

    if (!oid) {
        // invalid PKCS7 file
        log_message("The file " + filepath + "is not a valid PKCS#7 file.")
        return pcerts;
    }
    var next2 = next.sub[0];

    //log_message("Found " + next2.sub.length + " ASN.1 parts");
    for(i = 0; i < next2.sub.length; i++) {
        if ((next2.sub[i].tag >> 6) == 2) {
            var certs = next2.sub[i];
            log_message("Found " + certs.sub.length + " certs in " + filepath);
            for (j = 0; j < certs.sub.length; j++) {
                var certdata = der.slice(certs.sub[j].posContent()-certs.sub[j].header, certs.sub[j].posContent() + certs.sub[j].length);
                pcerts.push(certdata);
            }
        }
    }

    return pcerts;
}


function base64_encode(input) {

// Copyright 2003-2009 Christian d'Heureuse, Inventec Informatik AG, Zurich, Switzerland
// www.source-code.biz, www.inventec.ch/chdh
//
// This module is multi-licensed and may be used under the terms
// of any of the following licenses:
//
//  EPL, Eclipse Public License, http://www.eclipse.org/legal
//  LGPL, GNU Lesser General Public License, http://www.gnu.org/licenses/lgpl.html
//  AL, Apache License, http://www.apache.org/licenses
//  BSD, BSD License, http://www.opensource.org/licenses/bsd-license.php
//
// Please contact the author if you need another license.
// This module is provided "as is", without warranties of any kind.

//package biz.source_code.base64Coder;

/**
* A Base64 Encoder/Decoder.
*
* <p>
* This class is used to encode and decode data in Base64 format as described in RFC 1521.
*
* <p>
* Home page: <a href="http://www.source-code.biz">www.source-code.biz</a><br>
* Author: Christian d'Heureuse, Inventec Informatik AG, Zurich, Switzerland<br>
* Multi-licensed: EPL/LGPL/AL/BSD.
*
* <p>
* Version history:<br>
* 2003-07-22 Christian d'Heureuse (chdh): Module created.<br>
* 2005-08-11 chdh: Lincense changed from GPL to LGPL.<br>
* 2006-11-21 chdh:<br>
*  &nbsp; Method encode(String) renamed to encodeString(String).<br>
*  &nbsp; Method decode(String) renamed to decodeString(String).<br>
*  &nbsp; New method encode(byte[],int) added.<br>
*  &nbsp; New method decode(String) added.<br>
* 2009-07-16: Additional licenses (EPL/AL) added.<br>
* 2009-09-16: Additional license (BSD) added.<br>
* 2009-09-16: Additional license (BSD) added.<br>
* 2010-01-27: Package name added.<br>
*/

   var map1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
   var iLen = input.length;
   
   var oDataLen = parseInt((iLen*4+2)/3);       // output length without padding
   var oLen = parseInt(((iLen+2)/3)*4);         // output length including padding
   var out = new Array();
   var ip = 0;
   var op = 0;
   while (ip < iLen) {
      var i0 = input[ip++] & 0xff;
      var i1 = ip < iLen ? input[ip++] & 0xff : 0;
      var i2 = ip < iLen ? input[ip++] & 0xff : 0;
      var o0 = i0 >>> 2;
      var o1 = ((i0 &   3) << 4) | (i1 >>> 4);
      var o2 = ((i1 & 0xf) << 2) | (i2 >>> 6);
      var o3 = i2 & 0x3F;
      out[op++] = map1[o0];
      out[op++] = map1[o1];
      out[op] = op < oDataLen ? map1[o2] : '='; op++;
      out[op] = op < oDataLen ? map1[o3] : '='; op++;
   }

   return out.join("");
}


/////////// LDAP Setup

function install_ldap() {
    // returns name of default LDAP server
    add_jeds();
    add_ako();
    return add_dod411();
}

function add_ako(){
    var user=prompt('Enter your AKO/DKO user name.  Click cancel if you do not use AKO/DKO.');
    
    if (user == null) {
        return false;
    }
    
    var attrs = "ldap_2.servers.default.attrmap.";
    prefManager.setCharPref(attrs + "DisplayName", "displayname,cn,commonname");
 
    var nospaces = add_ldap("AKO", "ldaps://directory.us.army.mil:636/ou=people,ou=army,ou=dod,o=U.S.%20Government,c=US??sub?(objectclass=*)");
    prefManager.setCharPref("ldap_2.servers." + nospaces + ".auth.dn", "cn=" + user + ",ou=people,ou=army,ou=dod,o=U.S. Government,c=US");
    prefManager.setIntPref("ldap_2.servers." + nospaces + ".maxHits", 1000);
    prefManager.setCharPref("ldap_2.servers." + nospaces + ".autoComplete.commentFormat", "[departmentnumber]");
    
    prefManager.setIntPref("mail.autoComplete.commentColumn", 2);
    
    return nospaces;
}

function add_jeds(){
    // to support more JEDS information
    var attrs = "ldap_2.servers.default.attrmap.";
    prefManager.setCharPref(attrs + "Custom1", "mozillaCustom1,custom1,employeeNumber");
    prefManager.setCharPref(attrs + "Custom2", "mozillaCustom2,custom2,rank");
    prefManager.setCharPref(attrs + "Custom3", "mozillaCustom3,custom3,dsnTelephoneNumber");
    prefManager.setCharPref(attrs + "Custom4", "mozillaCustom4,custom4,clearance");
    prefManager.setCharPref(attrs + "Department", "ou,department,departmentnumber,orgunit,component");
    prefManager.setCharPref(attrs + "FaxNumber", "fax,facsimiletelephonenumber,facsimileTelephoneNumber");
    prefManager.setCharPref(attrs + "HomeCountry", "mozillaHomeCountryName,citizenship");
    prefManager.setCharPref(attrs + "JobTitle", "title,position");
    prefManager.setCharPref(attrs + "PrimaryEmail", "mail,niprnetEmail");
    prefManager.setCharPref(attrs + "SecondEmail", "mozillaSecondEmail,xmozillasecondemail,siprnetEmail");
    
    var nospaces = add_ldap("JEDS", "ldaps://jeds.gds.disa.mil:636/OU=PKI,OU=DOD,O=U.S. Government,C=US??sub?(objectclass=*)");
    prefManager.setIntPref("ldap_2.servers." + nospaces + ".maxHits", 1000);
    prefManager.setCharPref("ldap_2.servers." + nospaces + ".autoComplete.commentFormat", "[ou]");
    
    prefManager.setIntPref("mail.autoComplete.commentColumn", 2);    
    
    return nospaces;
}

function add_dod411() {
    var nospaces =  add_ldap("DoD 411", "ldaps://dod411.gds.disa.mil:636/ou=DoD, o=U.S. Government,c=us??sub?(objectclass=*)");
    prefManager.setIntPref("ldap_2.servers." + nospaces + ".maxHits", 1000);
    prefManager.setCharPref("ldap_2.servers." + nospaces + ".autoComplete.commentFormat", "[ou]");

    prefManager.setIntPref("mail.autoComplete.commentColumn", 2);   

    return nospaces;
}

function add_ldap(name, uri) {
    //remove spaces from name
    var nospaces_array = name.split(" ");
    var nospaces = "";
    for(i = 0; i < nospaces_array.length; i++) {
        nospaces += nospaces_array[i];
    }

    prefManager.setCharPref("ldap_2.servers." + nospaces + ".uri", uri);
    prefManager.setCharPref("ldap_2.servers." + nospaces + ".description", name);
    try {
	prefManager.clearUserPref("ldap_2.servers." + nospaces + ".position");
    } catch (e) {};

    return nospaces;
}

