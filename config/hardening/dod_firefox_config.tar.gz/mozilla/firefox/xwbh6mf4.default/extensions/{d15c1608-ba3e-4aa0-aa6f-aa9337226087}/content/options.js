/*######################################################################
#
# Project: DoD Configuration Extension
# URL: https://software.forge.mil/sf/projects/community_cac
# E-mail: neil.mcnab@navy.mil
# E-mail: neil.mcnab@us.army.mil
# E-mail: neil.mcnab@ugov.gov
#
# Copyright: (C) 2003-2011, Neil McNab
# License: GNU General Public License Version 2
#   (http://www.gnu.org/copyleft/gpl.html)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
#
# Filename: $URL: https://svn.forge.mil/svn/repos/mozilla-dodconfig/trunk/dod_configuration/content/options.js $
# Author(s): Neil McNab
# Last Updated: $Date: 2011-08-19 12:10:36 -0400 (Fri, 19 Aug 2011) $
#
######################################################################*/

function dod_initialize_options() {
	var count = 0;
	var myvalue = {};

    dod_classifications = document.getElementById("dod_classifications");

	children_list = get_array("extensions.dod.classification.");


	if (isBrowser()) {
		//populate options interface for browser
		document.getElementById("dod_browser_options").hidden = false;
		//document.getElementById("addsearches").hidden = false;
		
	}

	if (isMail()) {
		//populate options interface for mail
		document.getElementById("dod_mail_options").hidden = false;
        document.getElementById("addldap").hidden = false;

		var previous = "";
		var prefdod = document.getElementById("prefdod");

		for (i = 0; i < children_list.length; i++) {
			var component_list = children_list[i].split(".");
			var security_domain = component_list[0];
			var level = component_list[1];
			var root = component_list[2];

			var label = prefManager.getCharPref("extensions.dod.classification." + children_list[i]);

			if (security_domain != previous) {
				// create a menu for each security domain
				var menu = document.createElement("menulist");

				menu.setAttribute("id", "dod_list_" + security_domain);
				menu.setAttribute("preference", "prefdod_dod_list_" + security_domain);
				menu.addEventListener('command', update_defaults_list, false);
				menu.label = security_domain;

				var popup = document.createElement("menupopup")
				menu.appendChild(popup);

				//add none selection
				var myitem = document.createElement("menuitem");
				myitem.setAttribute("label", security_domain + " (none)");
				myitem.setAttribute("value", 0);

				popup.appendChild(myitem);

				dod_classifications.appendChild(menu);

				// register preferences
				var pref = document.createElement("preference");
				pref.setAttribute("id", "prefdod_dod_list_" + security_domain);
				pref.setAttribute("name", "extensions.dod.max_level." + security_domain);
				pref.setAttribute("type", "int");
				prefdod.appendChild(pref);

				previous = security_domain;
			}
			if (root == 0) {
				// add an item to the menu for each major security domain classification
				var myitem = document.createElement("menuitem");
				label = label.split(";")[0];
				myitem.setAttribute("label", security_domain + " " + label);
				myitem.setAttribute("value", level);
				popup.appendChild(myitem);
			}
		}

		children_list = get_array("extensions.dod.max_level.");
		for (i = 0; i < children_list.length; i++) {
			var security_domain = children_list[i];
			var domain_box = document.getElementById("dod_list_" + security_domain);
			domain_box.setAttribute("value", prefManager.getIntPref("extensions.dod.max_level." + security_domain));
		}
		// not sure why, but the delay is needed here

		window.setTimeout('update_defaults_list()', 200);

            window.setTimeout('dod_classification_checkbox(prefManager.getBoolPref("extensions.dod.enable_classification"))', 300);

	}
}

//function dod_save_options() {

	// save selections to preferences

	//if (isMail()) {
		//children_list = get_array("extensions.dod.max_level.");
		//for (i = 0; i < children_list.length; i++) {
		//	var security_domain = children_list[i];
		//	var domain_box = document.getElementById("dod_list_" + security_domain);
		//	prefManager.setIntPref("extensions.dod.max_level." + security_domain, domain_box.value);
		//}
		//alert(dod_listbox.value);
		//prefManager.setCharPref("extensions.dod.default_classification", dod_listbox.value);
		//dod_update_security_level();
	//}
//}

function update_defaults_list() {
	// populate the available classifications based on the levels selected
	name = "dod_default_listbox";
    allow_none = true;

	children_list = get_array("extensions.dod.classification.");

	var dod_listbox = document.getElementById(name);
	dod_listbox.removeAllItems();
	//dod_listbox.hidden = false;

	for (i = 0; i < children_list.length; i++) {
		var component_list = children_list[i].split(".");
		var security_domain = component_list[0];
		var level = component_list[1];

		var label = prefManager.getCharPref("extensions.dod.classification." + children_list[i]);
		var menu = document.getElementById("dod_list_" + security_domain);

		if (menu.value >= level) {
                        //alert("valid!");
			label = label.split(";")[0];
			dod_listbox.appendItem(security_domain + " " + label, children_list[i]);
		}
	}
	if (allow_none) {
		dod_listbox.appendItem("(None)", "");
	}
	
	dod_listbox.value = prefManager.getCharPref("extensions.dod.default_classification");

	return dod_listbox;
}

function dod_classification_checkbox(value) {
    var set = !value;
    document.getElementById('dodRequireClassification').disabled = set;
    document.getElementById('dodSubjectClassification').disabled = set;
    document.getElementById('dodBodyClassification').disabled = set;
    document.getElementById('dod_default_listbox').disabled = set;
    var list = document.getElementById('dod_classifications').childNodes;
    var i = 0;
    for(i = 0; i < list.length; i++) {
        list.item(i).disabled = set;
    }
}