/*######################################################################
#
# Project: DoD Configuration Extension
# URL: https://software.forge.mil/sf/projects/community_cac
# E-mail: neil.mcnab@navy.mil
# E-mail: neil.mcnab@us.army.mil
# E-mail: neil.mcnab@ugov.gov
#
# Copyright: (C) 2003-2009, Neil McNab
# License: GNU General Public License Version 2
#   (http://www.gnu.org/copyleft/gpl.html)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
#
# Filename: $URL: https://svn.forge.mil/svn/repos/mozilla-dodconfig/trunk/dod_configuration/content/compose.js $
# Author(s): Neil McNab
# Last Updated: $Date: 2010-06-11 19:00:33 -0400 (Fri, 11 Jun 2010) $
#
######################################################################*/

// intercept send command
addEventListener("load", function () {
    var oldsm = GenericSendMessage;
    GenericSendMessage = function (mode) {
        var dod_listbox = document.getElementById("classification_box");
        if (prefManager.getBoolPref("extensions.dod.require_classification") && dod_listbox.value == "") {
            alert("You need to select a classification.");
            return;
        }
        //var temp = set_headers(dod_listbox.label);
        oldsm(mode);
        //reset_headers(temp);
        }
    }, false);

// need to do this instead of just a straight load or compose editor is not all there.
var oldsm = ComposeLoad;
ComposeLoad = function () {
    oldsm();
    populate_classification_list();
};
    
document.getElementById( "msgcomposeWindow" ).addEventListener("compose-window-reopen", populate_classification_list, false);

/////// these don't work right yet, not called
function set_headers(classification) {
    var temp = prefManager.getCharPref("mailnews.customHeaders");
    alert("setting classification to" + classification);
    if (classification != "") {
        var newheaders = temp;
        if (newheaders.length > 0) {
            newheaders += ",";
        }
        newheaders += "X-Security-Classification: " + classification + ",X-P772-Security-Classification: " + classification;
        prefManager.setCharPref("mailnews.customHeaders", newheaders);
    }
    return temp;
}

function reset_headers(orig) {
    prefManager.setCharPref("mailnews.customHeaders", orig);
}

////////////////

function populate_classification_list() {
    var enabled = prefManager.getBoolPref("extensions.dod.enable_classification");

    if (!enabled) {
	      var dod_box = document.getElementById("dod_box");
          dod_box.hidden = true;
          return;
      }

	var name = "classification_box";

    var allow_none = true;
    //var allow_none = !prefManager.getBoolPref("extensions.dod.require_classification");

	children_list = get_array("extensions.dod.classification.");

	var dod_listbox = document.getElementById(name);
	dod_listbox.removeAllItems();
	dod_listbox.hidden = false;

	for (i = 0; i < children_list.length; i++) {

		var component_list = children_list[i].split(".");
		var security_domain = component_list[0];
		var level = component_list[1];

		var label = prefManager.getCharPref("extensions.dod.classification." + children_list[i]);
            
            //alert(prefManager.getIntPref("extensions.dod.max_level." + security_domain) + level);
		
		if (prefManager.getIntPref("extensions.dod.max_level." + security_domain) >= level) {
			//alert(security_domain);
			label = label.split(";")[0];
			dod_listbox.appendItem(security_domain + " - " + label, children_list[i]);
		}
	}

	if (allow_none) {
		dod_listbox.appendItem("(None)", "");
	}
	
	dod_listbox.value = prefManager.getCharPref("extensions.dod.default_classification");
    set_classification(dod_listbox.value);
    //read_classification();

	return dod_listbox;
}

function read_classification() {
    var content = document.getElementById("content-frame");
    var html = content.getHTMLEditor(content.contentWindow);
    var body = html.getElementOrParentByTagName("body", html.rootElement);
    var result = body.innerHTML.indexOf("Classification: ");
    if (result < 0) {
        var result = body.innerHTML.indexOf("CLASSIFICATION: ");
    }
    if (result >= 0) {
        var result = body.innerHTML.indexOf("<br>");
        if (result >= 0) {
            var classification = body.innerHTML.substr(16, result-16);
            return classification;
        }
    }
    return "";
}

function set_classification(value) {
    var label = "";
    var short = "";
    var verbose = "";
    // catch errors when value is null
    try {
        var label = prefManager.getCharPref("extensions.dod.classification." + value);
        var short = label.split(";")[1];
        var verbose = label.split(";")[0];
    } catch (e) {};

    var subject_line = document.getElementById("msgSubject");
    // remove subject classification
    if (subject_line.value[0] == "(") {
        var result = subject_line.value.indexOf(")");
        if (result >= 0) {
            subject_line.value = subject_line.value.substr(result+2);
        }
    }
    // set subject classification
    if (prefManager.getBoolPref("extensions.dod.subject_classification") && short != "") {
        subject_line.value = "(" + short + ") " + subject_line.value; 
    }

    var content = document.getElementById("content-frame");
    var html = content.getHTMLEditor(content.contentWindow);
    var body = html.getElementOrParentByTagName("body", html.rootElement);
    // Remove previous classification from body
    // TODO fix this when opening a saved draft
    if (body.innerHTML.indexOf("Classification: ") == 0 || body.innerHTML.indexOf("CLASSIFICATION: ") == 0) {
        var result = body.innerHTML.indexOf("<br><br>");
        if (result >= 0) {
            body.innerHTML = body.innerHTML.substr(result+8);
        }
        var end = body.innerHTML.lastIndexOf("Classification: ");
        if (end >= 0) {
            body.innerHTML = body.innerHTML.substr(0, end-8);
        }
        var end = body.innerHTML.lastIndexOf("CLASSIFICATION: ");
        if (end >= 0) {
            body.innerHTML = body.innerHTML.substr(0, end-8);
        }
    }
    //set top /bottom of body 
    if (prefManager.getBoolPref("extensions.dod.body_classification") && verbose != "") {
        body.innerHTML = "Classification: " + verbose + "<br><br>" + body.innerHTML + "<br><br>Classification: " + verbose + "<br><br>";
    }

    // set e-mail header
/*
    var addressing = document.getElementById("addressingWidget");
    var i = 0;
    for(i = 0; i < addressing.childNodes.length; i++) {
        var node = addressing.childNodes.item(i);
        if (node.localName == "listitem") {
            //alert(node.childNodes.item(0).firstChild);
            var menu = node.childNodes.item(0).firstChild;
            var text = node.childNodes.item(1).firstChild;
            try {
                if (menu.label == "X-Security-Classification:") {
                    text.value = label;
                    text.disabled = true;
                    menu.disabled = true;
                    return;
                }
            } catch (e) {};
        }
    }

    // can't start with 0 because that makes all fields disabled!
    for(i = 0; i < addressing.childNodes.length; i++) {
        var node = addressing.childNodes.item(i);
        if (node.localName == "listitem") {
            var menu = node.childNodes.item(0).firstChild;
            var text = node.childNodes.item(1).firstChild;
            try {
                if (text.value == "") {
                    menu.appendItem("X-Security-Classification:", "addr_other");
                    menu.selectedIndex = menu.firstChild.childNodes.length-1;
                    text.value = label;
                    text.disabled = true;
                    menu.disabled = true;
                    return;
                }
            } catch (e) {};
        }
    }
*/
}