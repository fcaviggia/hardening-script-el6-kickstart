/*######################################################################
#
# Project: DoD Configuration Extension
# URL: https://software.forge.mil/sf/projects/community_cac
# E-mail: neil.mcnab@navy.mil
#
# Copyright: (C) 2003-2009, Neil McNab
# License: GNU General Public License Version 2
#   (http://www.gnu.org/copyleft/gpl.html)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
#
# Filename: $URL: https://svn.forge.mil/svn/repos/mozilla-dodconfig/trunk/dod_configuration/defaults/preferences/dod.js $
# Author(s): Neil McNab
# Last Updated: $Date: 2010-02-01 17:42:16 -0500 (Mon, 01 Feb 2010) $
#
######################################################################*/

pref("extensions.dod.version", 0);
pref("extensions.dod.domain", "mil");

// browser prefs
pref("extensions.dod.enable_domain_highlight", true);
pref("extensions.dod.enable_cac_alert", true);
pref("extensions.dod.enable_https_redirect", true);

// mail prefs
pref("extensions.dod.forged_warning", true);
pref("extensions.dod.replyall_warning", true);

pref("extensions.dod.enable_classification", true);
pref("extensions.dod.require_classification", false);
pref("extensions.dod.subject_classification", false);
pref("extensions.dod.body_classification", true);
pref("extensions.dod.default_classification", "");
pref("extensions.dod.security_level", 50);

// setup standard classification levels
// USA
pref("extensions.dod.classification.USA.10.0", "UNCLASSIFIED;U");
pref("extensions.dod.classification.USA.10.1", "UNCLASSIFIED//CONTROLLED UNCLASSIFIED INFORMATION;U//CUI");
pref("extensions.dod.classification.USA.10.2", "UNCLASSIFIED//FOR OFFICIAL USE ONLY;U//FOUO");
pref("extensions.dod.classification.USA.10.3", "UNCLASSIFIED//HIPPA;U//HIPPA");
pref("extensions.dod.classification.USA.10.4", "UNCLASSIFIED//PRIVACY ACT SENSITIVE;U//PRIVACY ACT SENSITIVE");
pref("extensions.dod.classification.USA.10.5", "UNCLASSIFIED//LAW ENFORCEMENT SENSITIVE;U//LES");
pref("extensions.dod.classification.USA.10.6", "UNCLASSIFIED//PROPRIETARY;U//PROPRIETARY");
pref("extensions.dod.classification.USA.20.0", "CONFIDENTIAL;C");
pref("extensions.dod.classification.USA.30.0", "SECRET;S");
pref("extensions.dod.classification.USA.30.1", "SECRET//NO FOREIGN NATIONALS;S//NOFORN");
pref("extensions.dod.classification.USA.30.2", "SECRET//RELEASABLE;S//REL");
pref("extensions.dod.classification.USA.30.3", "SECRET//RELEASABLE TO USA,AUS,CAN,GBR,NZL;S//REL USA,AUS,CAN,GBR,NZL");
pref("extensions.dod.classification.USA.40.0", "TOP SECRET;TS");
pref("extensions.dod.classification.USA.40.1", "TOP SECRET//RESTRICTED DATA;TS//RD");
pref("extensions.dod.max_level.USA", 10);

// NATO
pref("extensions.dod.classification.NATO.10.0", "UNCLASSIFIED;NU");
pref("extensions.dod.classification.NATO.20.0", "RESTRICTED;NR");
pref("extensions.dod.classification.NATO.30.0", "CONFIDENTIAL;NC");
pref("extensions.dod.classification.NATO.40.0", "SECRET;NS");
pref("extensions.dod.classification.NATO.50.0", "COSMIC TOP SECRET;CTS");
pref("extensions.dod.max_level.NATO", 0);

// Corporate
pref("extensions.dod.classification.CORPORATE.10.0", "PUBLIC;PUBLIC");
pref("extensions.dod.classification.CORPORATE.20.0", "INTERNAL;INTERNAL");
pref("extensions.dod.classification.CORPORATE.30.0", "SENSITIVE;SENSITIVE");
pref("extensions.dod.classification.CORPORATE.40.0", "PRIVATE;PRIVATE");
pref("extensions.dod.classification.CORPORATE.50.0", "CONFIDENTIAL;CONFIDENTIAL");
pref("extensions.dod.max_level.CORPORATE", 0);